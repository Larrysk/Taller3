package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.db.DbContactos;
import com.example.myapplication.entidades.Contactos;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class VerActivity extends AppCompatActivity {


    EditText txtname,txtphone,txtemail;
    Button btnGuarda;
    FloatingActionButton fabeditar,fabeliminar;
    Contactos contacto;
    int id =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);

    txtname=findViewById(R.id.txtname);
    txtphone=findViewById(R.id.txtphone);
    txtemail= findViewById(R.id.txtemail);
        btnGuarda= findViewById(R.id.btnguardar);
        fabeditar= findViewById(R.id.fabEditar);
        fabeliminar= findViewById(R.id.fabeliminar);
        if(savedInstanceState ==null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null){
                id = Integer.parseInt(null);
        }else{
                id = extras.getInt("ID");
            }
        }else {
            id= (int) savedInstanceState.getSerializable("ID");
        }
        DbContactos dbContactos = new DbContactos(VerActivity.this);
        contacto =dbContactos.verContactos(id);
        if (contacto !=null){
            txtname.setText(contacto.getNombre());
            txtphone.setText(contacto.getTelefono());
            txtemail.setText(contacto.getCorreo_electronico());
            btnGuarda.setVisibility(View.INVISIBLE);
            txtname.setInputType(InputType.TYPE_NULL);
            txtphone.setInputType(InputType.TYPE_NULL);
            txtemail.setInputType(InputType.TYPE_NULL);
        }
        fabeditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VerActivity.this, EditarActivity.class);
                intent.putExtra("ID",id);
                startActivity(intent);
            }
        });
fabeliminar.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(VerActivity.this);
        builder.setMessage("¿desea eliminar este contacto")
                .setPositiveButton("SI", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {


                    if (dbContactos.eliminarContacto(id)){
                        lista();
                    }
                     }
                })
                .setNegativeButton("no", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).show();
    }
});

    }
    private void lista(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}