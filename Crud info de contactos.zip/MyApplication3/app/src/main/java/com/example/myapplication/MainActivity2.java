package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.db.DbContactos;

public class MainActivity2 extends AppCompatActivity {
    EditText txtname,txtphone,txtemail;
    Button btnguardar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    txtname= findViewById(R.id.txtname);
        txtname= findViewById(R.id.txtname);
        txtphone= findViewById(R.id.txtphone);
        txtemail= findViewById(R.id.txtemail);
        btnguardar= findViewById(R.id.btnguardar);
    btnguardar.setOnClickListener((view) -> {
            DbContactos dbContactos =new DbContactos(MainActivity2.this);
       long id = dbContactos.insentacontacto(txtname.getText().toString(),txtphone.getText().toString(),txtemail.getText().toString());

            if (id > 0) {
                Toast.makeText(MainActivity2.this,"Registro guardado",Toast.LENGTH_LONG).show();
                limpiar();
            }else {
                Toast.makeText(MainActivity2.this, "Error al guardar", Toast.LENGTH_LONG).show();
            }

    });
    }
    private void limpiar(){
        txtname.setText("");
        txtphone.setText("");
        txtemail.setText("");
    }
}