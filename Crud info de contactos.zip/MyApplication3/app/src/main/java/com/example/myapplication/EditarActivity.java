package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.db.DbContactos;
import com.example.myapplication.entidades.Contactos;

public class EditarActivity extends AppCompatActivity {


    EditText txtname,txtphone,txtemail;
    Button btnGuarda;
    boolean correcto = false;
    Contactos contacto;
    int id =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);

        txtname=findViewById(R.id.txtname);
        txtphone=findViewById(R.id.txtphone);
        txtemail= findViewById(R.id.txtemail);
        btnGuarda= findViewById(R.id.btnguardar);

        if(savedInstanceState ==null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null){
                id = Integer.parseInt(null);
            }else{
                id = extras.getInt("ID");
            }
        }else {
            id= (int) savedInstanceState.getSerializable("ID");
        }
        final DbContactos dbContactos = new DbContactos(EditarActivity.this);
        contacto =dbContactos.verContactos(id);
        if (contacto !=null){
            txtname.setText(contacto.getNombre());
            txtphone.setText(contacto.getTelefono());
            txtemail.setText(contacto.getCorreo_electronico());

        }

btnGuarda.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if(txtname.getText().toString().equals("") && !txtphone.getText().toString().equals("")){
            correcto= dbContactos.editarcontacto(id, txtname.getText().toString(),txtphone.getText().toString(),
                    txtemail.getText().toString());
            if (correcto) {
                Toast.makeText(EditarActivity.this,"Registro modificado",Toast.LENGTH_LONG).show();
                verRegistro();
            }else{
                Toast.makeText(EditarActivity.this,"Error al registro modificado",Toast.LENGTH_LONG).show();

            }
        }else {
            Toast.makeText(EditarActivity.this,"Debe llenar los campos obligatorios",Toast.LENGTH_LONG).show();

        }
    }
});
    }
    private void verRegistro(){
        Intent intent = new Intent(this,VerActivity.class);
        intent.putExtra("ID", id);
        startActivity(intent);
    }
}